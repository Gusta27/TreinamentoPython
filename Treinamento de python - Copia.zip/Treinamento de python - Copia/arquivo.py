# arquivo = open("arquivo.txt")

# # linhas = arquivo.readlines()
# # print(linhas)
# texto_completo = arquivo.read()
# print(texto_completo)
# w = open("arquivo2.txt", "w")

# w.write("Esse eh meu arquivo")
# w.close()

#read()
#le o arquivo inteiro

#READLINE()
#le uma linha

#READLINES()
#le arquivo e o armazena em uma lista 

