dicionario = {"A":"AMEIXA", "B":"BOLA", "C":"CACHORRO"}

for chave in dicionario.values():
    print(chave)

#dicionario.values() = mostra somente os valores
#dicionario.keys() = mostra somente as chaves
#dicionario.items() = mostra tudo
