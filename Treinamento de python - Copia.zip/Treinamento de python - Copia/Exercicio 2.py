nota = int(input("informe sua nota: "))
nota2 = int(input("informe a segunda nota: "))

soma = (nota+nota2)
resultado = (soma/2)

if resultado >= 6:
    print("aprovado")
else:
    print("reprovado")
    