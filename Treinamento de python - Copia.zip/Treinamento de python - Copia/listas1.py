minha_lista = ["abacaxi", "melancia", "abacate"]
minha_lista2 = [1, 2, 3, 4, 5]
minha_lista3 = ["abacaxi", 2, 9.8, True]
minha_lista4 = []

minha_lista4.append(57)
tamanho = len(minha_lista)
print(tamanho)
print(" \n")

minha_lista.append("limão")

del minha_lista[2:]
print(minha_lista4)

#del = apaga item da lista
#append = adiciona item a lista
#len mostra a posiçao do item na lista