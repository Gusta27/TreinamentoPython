lista = [124, 345, 72, 7, 9, 0]
lista2 = ["bola", "abacate", "dindin"]

lista2.sort()

print(lista2)

#reverse, reverter ordem
#sort = ordena
#sorted = ordena