import random
#random.seed(1) #resultar sempre o mesmo numero
#numero = random.randint(0, 10) # usado para escolher numeros aleatorios
lista = [6, 45, 9, 9, 10, 12]
numero = random.choice(lista)

print(numero)