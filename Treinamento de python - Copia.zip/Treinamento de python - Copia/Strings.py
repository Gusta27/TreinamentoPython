# -- coding: utf-8 --
#metodos de STRING
#minha_string = "o rato roeu a roupa do rei de roma"
#busca = minha_string.find("rei")
#print(minha_string[busca:])

minha_string = "o rato roeu a roupa do rei de roma"
minha_string = minha_string.replace("o rei","a rainha")
print(minha_string)

