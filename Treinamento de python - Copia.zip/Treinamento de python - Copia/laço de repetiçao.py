# -- coding: utf-8 --
#for laço de repetição em lista
lista1 = [1,2,3,4,5]
lista2 = ["ola", "mundo","!"]
lista3 = [0, "ola","biscoito","bolacha",9.99,True]

for i in range(10,20,2):
    print(i)
