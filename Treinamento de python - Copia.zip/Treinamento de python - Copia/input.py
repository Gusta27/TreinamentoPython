nome = input("Digite seu nome: ")
print(f"Ola, {nome}!")