# -- coding: utf-8 --

# def soma(x, y):
#     return x+y

# def multiplicacao(x, y):
#     return x*y

# s = soma(2, 3)
# m = multiplicacao(3, 4)

# print(multiplicacao(s, m))
