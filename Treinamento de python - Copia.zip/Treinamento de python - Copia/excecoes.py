a = 4
b = 0
try:
    print(a/b)
except:
    print("nao foi possivel!")
print(a/a)

