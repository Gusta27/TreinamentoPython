idade = int(input("qual a sua idade? "))

if idade >= 18:
    print("voce é maior de idade")
else:
    print("voce é criança")

